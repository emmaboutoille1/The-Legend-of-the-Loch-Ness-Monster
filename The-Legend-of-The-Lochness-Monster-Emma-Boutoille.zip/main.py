#Emma Boutoille
#April 22, 2021
#Interactive Story
#The Legend of The Loch Ness Monster

import sys #import system
import time #import time

text = "The Legend of The Loch Ness Monster" #title of story
for character in text: #process
  sys.stdout.write(character) #process
  sys.stdout.flush() #process
  time.sleep(0.06) #time it takes for typewriter to sleep

def typeWriter(text): #define typewriter effect for text
  for char in text: #process
    sys.stdout.write(char) #process
    sys.stdout.flush() #process
    time.sleep(0.06) #time it takes for typewriter to sleep

print("\n")
userName = input(typeWriter("Please enter your name: ")) #input name 
userColour = input(typeWriter("Please enter your favourite colour: ")) #input favourite colour
userHobby = input(typeWriter("Please enter one of your hobbies: ")) #input hobby
typeWriter(f"\nWelcome {userName}, are you ready to hear the story of the Legend of The Loch Ness Monster?") #print story text
print("\n") #print newline
answer1 = input(typeWriter("Please enter your response. Please choose either yes or no: ")) #input response
print("\n") #print newline
if answer1 == "yes": #process
  typeWriter("Great! Hopefully you'll enjoy the story.") #executes if user enters yes
elif answer1 == "no": #else if there is another condition
  typeWriter("That's too bad. Hopefully you'll enjoy the story anyways.") #executes if user enters no

print("\n") #print newline
typeWriter("To this day, no one has ever been able to solve the mystery of whether or not the Loch Ness monster is real, but as you dive into this story, you will be able to put those rumors to the test.") #print story text
print("\n") #print newline
typeWriter("You will find out for yourself, who was right all along.") #print story text

print("\n") #print newline
typeWriter("Let's go back to the mid 20th century, around  1933, when the first ever photograph of the famous Loch Ness Monster was taken.") #print story text
print("\n") #print newline
typeWriter("The photograph was taken by a British surgeon, who later had his picture published in the Daily Mail.") #print story text
print("\n") #print newline
typeWriter("More and more people claimed to also have seen this monster throughout the 20th century.") #print story text
print("\n") #print newline
typeWriter("However, after spending nearly a century searching for this monster that was never proven to have existed, people started thinking that the whole thing was a hoax.\n") #print story text

print("\n") #print newline
typeWriter("What do you think? Is the Loch Ness monster real?") #print story text
answer2 = input(typeWriter(" Please enter your response. Please choose either yes or no: ")) #input user response
print("\n") #print newline
if answer2 == "yes": #process
  typeWriter("Interesting. Let's see if this story convinces you even more.") #executes if user enters yes
elif answer2 == "no": #process
  typeWriter("That's ok. Who knows, maybe this story will make you change your mind?") #executes if user enters no

print("\n") #print newline
typeWriter(" Today, you are going to take a trip to Scotland, to see if you can spot the Loch Ness monster yourself.") #print story text
print("\n") #print newline
typeWriter("Unfortunately, because of the Coronavirus pandemic, you cannot leave the country for non-essential reasons.") #print story text
print("\n") #print newline
typeWriter("You decide to find a way to escape secretly.") #print story text
print("\n") #print newline
typeWriter("You are given 3 options but you are not told what each of the options are.") #print story text
typeWriter(" Ready? You will now randomly be asisgned a choice.") #print story text
print("\n") #print newline

import random #import random number
randomNumber = random.randint(1,3) #input random number
if randomNumber == 1: #process
  typeWriter("You have chosen to teleport to Scotland.") #executes if random number is equal to 1
  print("\n") #print newline
  typeWriter("A portal suddenly shows up in front of you, and you decide to jump in it.") #output
  print("\n") #print newline
  typeWriter("As you exit the portal, you arrive in Scotland.") #output
elif randomNumber == 2: #else if there is another condition
  typeWriter("You have chosen to go to Scotland by travelling underground.") #executes if random number is equal to 2
  print("\n") #print newline
  typeWriter("You find a lit up tunnel and you decide to follow it until the end, which leads you to Scotland.") #output
elif randomNumber == 3: #else if there is another condition
  typeWriter("You have been given a pair of wings, as you have chosen to fly to Scotland as a disguised bird.") #executes if random number is equal to 3
  print("\n") #print newline
  typeWriter("You put on your wings and lauch yourself into the sky.") #output
  print("\n") #print newline
  typeWriter("You run across a flock of seagulls who start circling around you, confused as to why you are there.") #output
  print("\n") #print newline
  typeWriter("Luckily, you end up becoming friends and the seagulls lead you the way to Scotland.") #output

print("\n") #print newline
typeWriter("You finally arrive to the Loch Ness and you see a green lump sticking out of the water.") #print story text
print("\n") #print newline
typeWriter("Should you be risky and check it out, or should you stay behind?") #print story text
print("\n") #print newline
typeWriter("To go check it out, enter go. To stay behind, enter stay.") #print story text

yourChoice1 = input(typeWriter(" Enter your choice here: ")) #input user choice
if yourChoice1 == "go": #process
  print("\n") #print newline
  typeWriter("Alright, let's head on over.") #executes if user enters go
  print("\n") #print newline
  typeWriter("You hop into a boat parked on the shore and paddle your way to the green lump.") #output
  print("\n") #print newline
  typeWriter("As you start to make your way towards your target, the green lump starts to shake, creating harsh waves in the loch.") #output
  print("\n") #print newline
  typeWriter("These waves will make it more difficult to steer the boat. Continuing with this trip could cause you to fall out.") #output
  print("\n") #print newline
  typeWriter("Do you wish to risk it and continue on with this trip or do you wish to turn around and head back to shore?") #output
  print("\n") #print newline
  typeWriter("To keep going, enter continue. To abbandon this mission, enter go back.") #output

elif yourChoice1 == "stay": #else if there is another condition
  print("\n") #print newline
  typeWriter("You decide to stay behind. You wait several hours hoping the grren lumps will come closer.") #executes if user enters stay
  print("\n") #print newline
  typeWriter("However, you are too far away to get a good enough view.") #output
  print("\n") #print newline
  typeWriter("You decide to get in the boat parked on the shore and make your way towards the green lump.") #output
  print("\n") #print newline
  typeWriter("That's when you realize that the waves are making it very difficult to steer the boat.") #output
  print("\n") #print newline
  typeWriter("Do you wish to risk it and continue on with this trip or do you wish to turn around and head back to shore?") #output
  print("\n") #print newline
  typeWriter("To keep going, enter continue. To abandon this mission, enter go back.") #output

print("\n") #print newline
yourChoice2 = input(typeWriter("Enter your choice here: ")) #input user choice
print("\n") #print newline
if yourChoice2 == "continue": #process
  typeWriter("You decide to keep making your way towards the green lump. Will your risk pay off?") #executes if user enters continue
elif yourChoice2 == "go back": #else if there is another condition
  typeWriter("You start to make your way back to the shore. You soon realize that the waves have gotten too strong for you to make it back safely.") #executes if user enters go back
  print("\n") #print newline
  typeWriter("You have no choice but to continue with the mission. You decide turn back around and head towards the green lump.") #output

print("\n") #print newline
typeWriter("Although it is challenging, you try your best to surround the waves.") #print story text
print("\n") #print newline
typeWriter("Luckily, the waves start to slow down and they come to a stop shortly after.") #print story text
print("\n") #print newline
typeWriter("Once you approach the green lump, you notice a bottle laying on the sand of the nearby island.") #print story text
print("\n") #print newline
typeWriter("You open the bottle and you find a message saying: Pick a number between 1 and 10. Add 8 to that number then add 5. Then subtract your original number. What is the new number?") #print story text
print("\n") #print newline
typeWriter("Did you solve the riddle yet?") #print story text

print("\n") #print newline
numberRiddle = int(input("If you did, enter the answer here: ")) #input user answer for number riddle
if numberRiddle == 13: #process
  print("\n") #print newline
  typeWriter("Lucky number 13, great work!") #executes if user enters 13
else: #process
  print("\n") #print newline
  typeWriter("Not quite. Please try again") #executes if user does not enter 13
  num1 = input(typeWriter("If you did, enter the answer here: ")) #input user answer for number riddle
  print("\n") #print newline
  typeWriter("Lucky number 13, great work!") #executes if user enters 13

print("\n") #print newline
typeWriter("After you enter the number 13, another message shows up at the back of the piece of paper on which the first message is written.") #print story text
print("\n") #print newline
typeWriter("Get closer to the water and you shall see the answer to this legendary mystery.") #print story text
print("\n") #print newline
typeWriter("Should you do what the message says, or should you stay put? \n To do what the message says enter listen to the message, to stay put enter stay put.") #print story text
yourDecision = input(typeWriter("Enter your decision here: ")) #input user decision
print("\n") #print newline
if yourDecision == "listen to the message": #process
  print("\n") #print newline
  typeWriter("Good choice. Now what are you waiting for, let's go to the water.") #executes if user enters listen to the message
elif yourDecision == "stay put": #else if there is another condition
  print("\n") #print newline
  typeWriter("Come on now, don't be scared. Trust me, it will all be worth it in the end.") #executes if user enters stay put
  print("\n") #print newline
  typeWriter("It looks like the only way to solve this mystery is to listen to the message's directions.") #output
  print("\n") #print newline
  typeWriter("You decide to head towards the water.") #output

print("\n") #print newline
typeWriter("Suddenly, The green lump starts to rise out of the water") #print story text
print("\n") #print newline
typeWriter("It turns out to be the Loch Ness monster after all.") #print story text
print("\n") #print newline
typeWriter("You quickly grab your phone to take a picture, but you realize it is out of battery, and unfortunately, you don't have a charger on hand.") #print story text
print("\n") #print newline
typeWriter("Will people believe that you saw the Loch Ness monster if you don't have any proof?") #print story text
print("\n") #print newline
typeWriter("Even if you did have a picture, will people still think that it is a hoax, just like they did when they thought the first few pictures of the monster were fake?") #print story text
print("\n") #print newline
typeWriter("It looks like the secret will have to stay within you. If people want to find out the truth, they will have to come find out for themselves, the same way you just did.") #print story text
print("\n") #print newline
typeWriter("But at least now you know, that the legend of the Loch Ness monster that people have been debating over for years, is true after all.") #print story text
print("\n") #print newline
typeWriter("Thanks for taking part in this interactive story. I hope you enjoyed it.") #print story text